package com.game.simpsonslemas;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.game.simpsonslemas.models.Personajes;
import com.squareup.picasso.Picasso;

public class DetailsActivity extends AppCompatActivity {

    ImageView imgPersonaje;
    TextView tvNombrePersonaje, tvOcupacionPersonaje,
            tvEdadPersonaje, tvEstadoPersonaje, tvFrasePersonaje;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        imgPersonaje = findViewById(R.id.imgPersonaje);
        tvNombrePersonaje = findViewById(R.id.tvNombrePersonaje);
        tvOcupacionPersonaje = findViewById(R.id.tvOcupacionPersonaje);
        tvEdadPersonaje = findViewById(R.id.tvEdadPersonaje);
        tvEstadoPersonaje = findViewById(R.id.tvEstadoPersonaje);
        tvFrasePersonaje = findViewById(R.id.tvFrasePersonaje);

        Personajes obj = (Personajes) getIntent().getSerializableExtra("PERSONAJE");

        if (obj != null) {

            String imagen = "https://cdn.thesimpsonsapi.com/200" + obj.getPortrait_path();
            Picasso.get().load(imagen).into(imgPersonaje);

            tvNombrePersonaje.setText(obj.getName());
            tvOcupacionPersonaje.setText(obj.getOccupation());

            if (obj.getAge() == 0) {
                tvEdadPersonaje.setVisibility(View.GONE);
            } else {
                tvEdadPersonaje.setVisibility(View.VISIBLE);
                tvEdadPersonaje.setText(String.valueOf(obj.getAge()));
            }

            if (obj.getStatus().equalsIgnoreCase("Deceased")) {
                tvEstadoPersonaje.setBackground(ContextCompat.getDrawable(this,
                        R.drawable.rectangle_deceased_textview));
                tvEstadoPersonaje.setTextColor(ContextCompat.getColor(this, R.color.red));
            } else {
                tvEstadoPersonaje.setBackground(ContextCompat.getDrawable(this,
                        R.drawable.rectangle_alive_textview));
                tvEstadoPersonaje.setTextColor(ContextCompat.getColor(this, R.color.green));
            }

            tvEstadoPersonaje.setText(obj.getStatus());

            String[] frases = obj.getPhrases();

            if (frases != null && frases.length > 0) {
                tvFrasePersonaje.setText(frases[0]);
            } else {
                tvFrasePersonaje.setText("Sin frase");
            }
        }
    }
}

